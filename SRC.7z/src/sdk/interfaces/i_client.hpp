#pragma once

#include <cstdint>
#include "../math/vec3_t.hpp"
#include "../../utilities/utilities.hpp"

class i_client
{
public:
	void set_view_angles(vec3_t angles)
	{

	}
};