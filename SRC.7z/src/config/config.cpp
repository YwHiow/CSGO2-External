#include "config.hpp"

extern config::config_t config::context = { };