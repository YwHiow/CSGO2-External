#include "../SDK/SDK.h"
#include "../interfaces.h"
#include "../settings.h"

namespace Teleport
{
	void CreateMove(CUserCmd* cmd);
}
