#pragma once

#include "../atgui.h"

namespace Aimbot
{
	void RenderTab();
}