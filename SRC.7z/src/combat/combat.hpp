#pragma once

#include "../source2-sdk/classes/user_cmd.hpp"

namespace combat
{
	void run_aimbot(user_cmd_t* cmd);
}